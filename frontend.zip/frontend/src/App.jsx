import "./App.css";
import Profile from "./Profile";

function App() {

  return <Profile />;
}

export default App;
