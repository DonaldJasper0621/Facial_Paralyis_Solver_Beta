export const BACKEND_HOST = "http://127.0.0.1";
export const BACKEND_PORT = "5000";
export const BACKEND_ENPPOINT = `${BACKEND_HOST}:${BACKEND_PORT}`;

export const route = { compare: "compare", upload: "upload" };
